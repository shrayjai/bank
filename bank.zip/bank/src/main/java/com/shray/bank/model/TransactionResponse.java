package com.shray.bank.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class TransactionResponse {

	private String accountNumber;

	private BigDecimal previousBalance;

	private BigDecimal updatedBalance;
}