package com.shray.bank.service;

import com.shray.bank.exception.AccountNotFoundException;
import com.shray.bank.exception.InsufficientBalanceException;
import com.shray.bank.exception.InvalidRequestException;
import com.shray.bank.model.BalanceResponse;
import com.shray.bank.model.TransactionRequest;
import com.shray.bank.model.TransactionResponse;
import com.shray.bank.model.TransferRequest;
import com.shray.bank.model.TransferResponse;

public interface BankService {

	BalanceResponse viewAccountBalance(String accountNumber) throws AccountNotFoundException;

	TransactionResponse depositCash(TransactionRequest request) throws AccountNotFoundException;

	TransactionResponse withdrawCash(TransactionRequest request)
			throws AccountNotFoundException, InsufficientBalanceException;

	TransferResponse transferMoney(TransferRequest request)
			throws AccountNotFoundException, InvalidRequestException, InsufficientBalanceException;
}