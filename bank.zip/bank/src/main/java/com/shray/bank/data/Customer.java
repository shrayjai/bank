package com.shray.bank.data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TBL_ACCOUNTS")
public class Customer {

	@Id
	@Column(name = "CID")
	private Long customerId;

	@Column(name = "NAME")
	private String name;

	@OneToMany(mappedBy = "customer")
	private List<Accounts> accounts = new ArrayList<>();
}