package com.shray.bank.data;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TBL_ACCOUNTS")
public class Accounts {

	@Id
	@Column(name = "ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name = "CARD_NUMBER")
	private String cardNumber;

	@Column(name = "BALANCE")
	private BigDecimal balance;

	@Column(name = "CID")
	private Long customerId;

	@ManyToOne(fetch = FetchType.LAZY)
	private Customer customer;
}