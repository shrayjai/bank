package com.shray.bank.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class TransferResponse {

	private String beneficiary;

	private BigDecimal amount;

	private String status;
}